INSERT INTO Appointments (appointmentDate, starttime,endtime,comment,doctor_username, patient_username, locationid)
VALUES ('2020-12-30', '19:04:00', '19:14:00', 'My back really hurts', NULL, 'm-le', 1);

INSERT INTO Appointments (appointmentDate, starttime,endtime,comment,doctor_username, patient_username, locationid)
VALUES ('2021-03-05', '16:00:00', '16:10:00', 'I want to remove a mole', NULL, 'm-le', 3);