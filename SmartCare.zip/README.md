# SmartCare
This is a coursework for the Enterprise System Design module, UWE Bristol 20-21

## Team members
Minh Le - 19035184  
Michael Tonkin - 18039133  
Giacomo Pellizzari - 17045579  
Asia Benyadilok - 18020561  
Deyvid Gueorguiev - 17017455  
